package com.example.demo.controllers;

import com.example.demo.dao.UserDao;
import com.example.demo.models.User;
import com.example.demo.services.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController("/user")
public class UserController {

    UserService service;

    @PostMapping("/createUser")
    public ResponseEntity<String> createUser(@RequestBody String body){
        try {
            String response = service.createUser(body);
            if( response != null && response.isEmpty()){
                return ResponseEntity.internalServerError().body("User not created");
            }else{
                return ResponseEntity.ok("User created with id "+response);
            }
        }catch(Exception e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }

    }
}
