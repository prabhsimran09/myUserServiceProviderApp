package com.example.demo.services;

import com.example.demo.dao.UserDao;
import com.example.demo.models.User;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
public class UserService {

    ObjectMapper objectMapper;
    UserDao userDao;

    public UserService(ObjectMapper objectMapper, UserDao userDao) {
        this.objectMapper = objectMapper;
        this.userDao = userDao;
    }

    public String createUser(String requestBody){
        Long userId = 0L;
        try {
            User user = objectMapper.readValue(requestBody, new TypeReference<User>() {
            });
            userId = userDao.persistUser(user.getUserID(), user.getUserName());
        }catch(Exception e){
            e.printStackTrace();
        }
        return "Created user with id : "+userId;
    }

//    public Set<User> listAllUsers(){
//        userDao.getAllUsers();
//    }
}
