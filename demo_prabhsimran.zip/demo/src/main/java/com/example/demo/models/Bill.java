package com.example.demo.models;

public class Bill {
}
