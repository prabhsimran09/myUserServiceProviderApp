package com.example.demo.dao;

import org.springframework.stereotype.Repository;

@Repository
public class UserDao {

//    NamedParameterJdbcTemplate namedParameterJdbcTemplate;

//    public UserDao(NamedParameterJdbcTemplate namedParameterJdbcTemplate){
//        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
//    }

    public Long persistUser(Long userId, String userName){

        String query = "INSERT into USER VALUES (:userId, :userName)";
//        SqlParameterSource params = new MapSqlParameterSource()
//                .addValue("userID", userId)
//                .addValue("userName", userName);

        //String userId = namedParameterJdbcTemplate.execute(query,params,);
        return 1L;
    }

}
